export const SliderSection = () => {

}